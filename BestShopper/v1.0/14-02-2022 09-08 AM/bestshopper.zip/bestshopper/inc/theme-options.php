<?php
/**
 * Initialize the options before anything else.
 */
add_action( 'init', 'custom_theme_options', 1 );
add_action( 'wp_head', 'bestshopper_bs_color_styles' );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
    /* OptionTree is not loaded yet, or this is not an admin request */
    if (!function_exists('ot_settings_id') || !is_admin()) return false;

    /**
     * Get a copy of the saved settings array.
     */
    $saved_settings = get_option('option_tree_settings', array());

    /**
     * Custom settings array that will eventually be
     * passes to the OptionTree Settings API Class.
     */
    $custom_settings = array(
        'contextual_help' => array(
            'content' => array(
                array(
                    'id'        => 'general_help',
                    'title'     => 'General',
                    'content'   => '<p>Help content goes here!</p>'
                )
            ) ,
            'sidebar' => '<p>Sidebar content goes here!</p>',
        ) ,
        'sections' => array(
            array(
                'id'    => 'general',
                'title' => __( 'General', 'bestshopper' )
            ),
            array(
                'id'    => 'bs_layout',
                'title' => __( 'Layout', 'bestshopper' )
            ),
            array(
                'id'    => 'bs_header',
                'title' => __( 'Header', 'bestshopper' )
            ),
            array(
                'id'    => 'bs_footer',
                'title' => __( 'Footer', 'bestshopper' )
            )
        ) ,
        'settings' => array(
            array(
                'id'      => 'bs_logo_upload',
                'label'   => __( 'Upload Logo', 'bestshopper' ),
                'desc'    => __( 'Upload the website logo', 'bestshopper' ),
                'type'    => 'upload',
                'section' => 'general'
            ),
            array(
                'id'      => 'bs_site_title',
                'label'   => __( 'Site Title', 'bestshopper' ),
                'desc'    => __( 'Add your site title', 'bestshopper' ),
                'type'    => 'text',
                'section' => 'general',
                'std'     => get_bloginfo( 'name' )
            ),
            array(
                'id'      => 'bs_site_sub_title',
                'label'   => __( 'Site Sub Title', 'bestshopper' ),
                'desc'    => __( 'Add your site sub title', 'bestshopper' ),
                'type'    => 'text',
                'section' => 'general',
                'std'     => get_bloginfo( 'description' )
            ),
            array(
                'id'      => 'bs_primary_color',
                'label'   => __( 'Primary Color', 'bestshopper' ),
                'desc'    => __( 'Choose your site primary color', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'general',
                'std'     => '#2382ff'
            ),
            array(
                'id'      => 'bs_text_color',
                'label'   => __( 'Text Color', 'bestshopper' ),
                'desc'    => __( 'Choose your site text color', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'general',
                'std'     => '#333333'
            ),
            array(
                'id'      => 'bs_hover_color',
                'label'   => __( 'Hover Color', 'bestshopper' ),
                'desc'    => __( 'Choose your site hover color', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'general',
                'std'     => '#2382ff'
            ),
            array(
                'id'      => 'bs_background_color',
                'label'   => __( 'Background Color', 'bestshopper' ),
                'desc'    => __( 'Choose your site background color. Your background color will unset if background image is set', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'general',
                'std'     => '#ffffff'
            ),
            array(
                'id'      => 'bs_body_background_image',
                'label'   => __( 'Upload Background Image', 'bestshopper' ),
                'desc'    => __( 'Upload the background image', 'bestshopper' ),
                'type'    => 'upload',
                'section' => 'general'
            ),
            array(
                'id'          => 'bs_body_background_position',
                'label'       => __( 'Background Position', 'bestshopper' ),
                'desc'        => __( 'Select the background position', 'bestshopper' ),
                'type'        => 'select',
                'section'     => 'general',
                'std'         => 'center',
                'choices'     => array( 
                    array(
                        'value'       => 'bottom',
                        'label'       => __( 'Bottom', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'center',
                        'label'       => __( 'Center', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'inherit',
                        'label'       => __( 'Inherit', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'initial',
                        'label'       => __( 'Initial', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'left',
                        'label'       => __( 'Left', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'revert',
                        'label'       => __( 'Revert', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'right',
                        'label'       => __( 'Right', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'top',
                        'label'       => __( 'Top', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'unset',
                        'label'       => __( 'Unset', 'bestshopper' ),
                    )
                )
            ),
            array(
                'id'          => 'bs_body_background_size',
                'label'       => __( 'Background Size', 'bestshopper' ),
                'desc'        => __( 'Select the background size', 'bestshopper' ),
                'type'        => 'select',
                'section'     => 'general',
                'std'         => 'contain',
                'choices'     => array( 
                    array(
                        'value'       => 'auto',
                        'label'       => __( 'Auto', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'contain',
                        'label'       => __( 'Contain', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'cover',
                        'label'       => __( 'Cover', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'inherit',
                        'label'       => __( 'Inherit', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'initial',
                        'label'       => __( 'Initial', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'revert',
                        'label'       => __( 'Revert', 'bestshopper' ),
                    ),
                    array(
                        'value'       => 'unset',
                        'label'       => __( 'Unset', 'bestshopper' ),
                    )
                )
            ),
            array(
                'id'      => 'bs_layout_type',
                'label'   => __( 'Layout Type', 'bestshopper' ),
                'desc'    =>  __( 'Choose a header layout for your theme', 'bestshopper' ),
                'std'     => 'right-sidebar',
                'type'    => 'radio-image',
                'section' => 'bs_layout',
                'class'   => 'header-type-img',
                'choices' => array(
                    array(
                        'value' => 'full-width',
                        'label' => __( 'Full Width', 'bestshopper' ),
                        'src'   => OT_URL . '/assets/images/layout/full-width.png'
                    ),
                    array(
                        'value' => 'right-sidebar',
                        'label' => __( 'Right Sidebar', 'bestshopper' ),
                        'src'   => OT_URL . '/assets/images/layout/right-sidebar.png'
                    ),
                    array(
                        'value' => 'left-sidebar',
                        'label' => __( 'Left Sidebar', 'bestshopper' ),
                        'src'   => OT_URL . '/assets/images/layout/left-sidebar.png'
                    )
                )
            ),
            array(
                'id'      => 'bs_layout_status',
                'label'   => __( 'Enable/Disable Sidebar', 'bestshopper' ),
                'desc'    => __( 'Enable/Disable Sidebar', 'bestshopper' ),
                'type'    => 'on-off',
                'section' => 'bs_layout',
                'std'     => 'on',
            ),
            array(
                'id'          => 'bs_select_sidebar',
                'label'       => __( 'Select Sidebar', 'bestshopper' ),
                'desc'        => __( 'Select the widget area for the sidebar', 'bestshopper' ),
                'std'         => 'sidebar-1',
                'type'        => 'sidebar-select',
                'section'     => 'bs_layout',
                'rows'        => '',
                'post_type'   => '',
                'taxonomy'    => '',
                'min_max_step'=> '',
                'class'       => 'bs-sidebar-select',
                'condition'   => '',
                'operator'    => 'and'
            ),
            array(
                'id'      => 'bs_header_background_color',
                'label'   => __( 'Header Background Color', 'bestshopper' ),
                'desc'    => __( 'Choose your header background color', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'bs_header',
                'std'     => '#f8f8f8'
            ),
            array(
                'id'      => 'bs_header_text_color',
                'label'   => __( 'Header Text Color', 'bestshopper' ),
                'desc'    => __( 'Choose your header text color', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'bs_header',
                'std'     => '#777777'
            ),
            array(
                'id'      => 'bs_header_hover_text_color',
                'label'   => __( 'Header Hover Text Color', 'bestshopper' ),
                'desc'    => __( 'Choose your header hover text color', 'bestshopper' ),
                'type'    => 'colorpicker',
                'section' => 'bs_header',
                'std'     => '#2382ff'
            ),
            array(
                'id'      => 'bs_header_type',
                'label'   => __( 'Header Type', 'bestshopper' ),
                'desc'    =>  __( 'Choose a header layout for your theme', 'bestshopper' ),
                'std'     => 'header-1',
                'type'    => 'radio-image',
                'section' => 'bs_header',
                'class'   => 'header-type-img',
                'choices' => array(
                    array(
                        'value' => 'header-1',
                        'label' => __( 'Logo Left/Menu Right', 'bestshopper' ),
                        'src'   => OT_URL . '/assets/images/header/header-1.png'
                    ),
                    array(
                        'value' => 'header-2',
                        'label' => __( 'Logo Top/Menu Bottom', 'bestshopper' ),
                        'src'   => OT_URL . '/assets/images/header/header-2.png'
                    )
                )
            ),
            array(
                'id'      => 'disable_footer_widgets',
                'label'   => __( 'Disable Footer Widgets', 'bestshopper' ),
                'desc'    => __( 'Check it to disable footer Widgets', 'bestshopper' ),
                'type'    => 'checkbox',
                'section' => 'bs_footer',
                'choices' => array( 
                    array(
                        'value' => 'yes',
                        'label' => __( 'Yes', 'bestshopper' ),
                    )
                )
            ),
            array(
                'id'      => 'bs_footer_type',
                'label'   => __('Footer Type', 'bestshopper'),
                'desc'    => __('Choose a footer layout for your theme', 'bestshopper'),
                'std'     => 'footer-1',
                'type'    => 'radio-image',
                'section' => 'bs_footer',
                'class'   => 'footer-type-img',
                'choices' => array(
                    array(
                        'value' => 'footer-1',
                        'label' => __('Footer 1', 'bestshopper'),
                        'src'   => OT_URL . '/assets/images/footer/footer-1.png'
                    ) ,
                    array(
                        'value' => 'footer-2',
                        'label' => __('Footer 2', 'bestshopper'),
                        'src'   => OT_URL . '/assets/images/footer/footer-2.png'
                    ) ,
                    array(
                        'value' => 'footer-3',
                        'label' => __('Footer 3', 'bestshopper'),
                        'src'   => OT_URL . '/assets/images/footer/footer-3.png'
                    ) ,
                    array(
                        'value' => 'footer-4',
                        'label' => __('Footer 4', 'bestshopper'),
                        'src'   => OT_URL . '/assets/images/footer/footer-4.png'
                    )
                )
            ),
            array(
                'id'    => 'bs_social_media_links',
                'label' => __( 'Social Links', 'bestshopper' ),
                'desc'  => __( 'Add your respective social media profiles.', 'bestshopper' ),
                'std'   => array(
                    array(
                        'title' => __('Facebook', 'bestshopper'), 
                        'bs_social_media_icon' => 'facebook', 
                        'bs_social_media_link' => '#'
                    ),
                    array(
                        'title' => __('Twitter', 'bestshopper'), 
                        'bs_social_media_icon' => 'twitter', 
                        'bs_social_media_link' => '#'
                    ),
                    array(
                        'title' => __('Instagram', 'bestshopper'), 
                        'bs_social_media_icon' => 'instagram', 
                        'bs_social_media_link' => '#'
                    ),
                ),
                'type'     => 'list-item',
                'section'  => 'bs_footer',
                'operator' => 'and',
                'settings' => array(
                    array(
                        'id'           => 'bs_social_media_icon',
                        'label'        => __( 'Select Icon', 'bestshopper' ),
                        'desc'         => __( 'Select the social media icon.', 'bestshopper' ),
                        'std'          => '',
                        'type'         => 'Select',
                        'section'      => 'option_types',
                        'rows'         => '',
                        'post_type'    => '',
                        'taxonomy'     => '',
                        'min_max_step' => '',
                        'class'        => '',
                        'condition'    => '',
                        'operator'     => 'and',
                        'choices'      => array( 
                            array(
                                'value' => '',
                                'label' => __( '-- Choose One --', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'facebook',
                                'label' => __( 'facebook', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'twitter',
                                'label' => __( 'Twitter', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'instagram',
                                'label' => __( 'Instagram', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'linkedin',
                                'label' => __( 'Linkedin', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'pinterest',
                                'label' => __( 'Pinterest', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'vkontakte',
                                'label' => __( 'Vkontakte', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'youtube',
                                'label' => __( 'Youtube', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'dribbble',
                                'label' => __( 'Dribbble', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'reddit',
                                'label' => __( 'Reddit', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'whatsapp',
                                'label' => __( 'Whatsapp', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'slack',
                                'label' => __( 'Slack', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'github',
                                'label' => __( 'Github', 'bestshopper' ),
                                'src'   => ''
                            ),
                            array(
                                'value' => 'stack-overflow',
                                'label' => __( 'Stack Overflow', 'bestshopper' ),
                                'src'   => ''
                            ),
                        )
                    ),
                    array(
                        'id'       => 'bs_social_media_link',
                        'label'    => __( 'Link', 'bestshopper' ),
                        'desc'     => __( 'The link of your social media profile.', 'bestshopper' ),
                        'std'      => '',
                        'type'     => 'text',
                        'operator' => 'and'
                    ),
                )
            ),
        ),
    );

    /* settings are not the same update the DB */
    if ($saved_settings !== $custom_settings)
    {
        update_option('option_tree_settings', $custom_settings);
    }

    /* Lets OptionTree know the UI Builder is being overridden */
    global $ot_has_custom_theme_options;
    $ot_has_custom_theme_options = true;
}

/**
 * Binds dynamic css for colors.
 */
function bestshopper_bs_color_styles() {
    printf( '<style type="text/css" id="bestshopper_bs_dynamic_css">' );
    bestshopper_bs_customizer_dynamic_css();
    printf( '</style>' );
}

/**
 * Generate dynamic css based on users selection.
 */
function bestshopper_bs_customizer_dynamic_css() {
    // General
    $primary_color   = !empty(ot_get_option( 'bs_primary_color' )) ? ot_get_option( 'bs_primary_color' ) : '#2382ff';
    $text_color      = !empty(ot_get_option( 'bs_text_color' )) ? ot_get_option( 'bs_text_color' ) : '#333333';
    $hover_color     = !empty(ot_get_option( 'bs_hover_color' )) ? ot_get_option( 'bs_hover_color' ) : '#2382ff';

    // Header
    $bs_header_background_color = !empty(ot_get_option( 'bs_header_background_color' )) ? ot_get_option( 'bs_header_background_color' ) : '#f8f8f8';
    $bs_header_text_color       = !empty(ot_get_option( 'bs_header_text_color' )) ? ot_get_option( 'bs_header_text_color' ) : '#777777';
    $bs_header_hover_text_color = !empty(ot_get_option( 'bs_header_hover_text_color' )) ? ot_get_option( 'bs_header_hover_text_color' ) : '#2382ff';
    $bs_background_color = !empty(ot_get_option( 'bs_background_color' )) ? ot_get_option( 'bs_background_color' ) : '#ffffff';
    $bs_body_background_image = !empty(ot_get_option( 'bs_body_background_image' )) ? ot_get_option( 'bs_body_background_image' ) : '';

    if(!empty($bs_body_background_image)) {
        $bs_body_background_position = !empty(ot_get_option( 'bs_body_background_position' )) ? ot_get_option( 'bs_body_background_position' ) : 'center';
        $bs_body_background_size = !empty(ot_get_option( 'bs_body_background_size' )) ? ot_get_option( 'bs_body_background_size' ) : 'contain';

        printf( 'body { background: url(%s); background-repeat: no-repeat; background-position: %s; background-size: %s;}', $bs_body_background_image, $bs_body_background_position, $bs_body_background_size);
    } else {
        printf( 'body { background-color: %s; }', $bs_background_color);
    }


    printf( '.primary-bg, .btn-primary, .site-header .bootsnipp-search .search-form .input-group-btn > .search-submit, .navbar-default .navbar-nav > .current-menu-item > a:after, .widget .widget-title:after, .comment-form .form-submit input[type="submit"], .calendar_wrap > table > tbody tr td#today, .page-header:after, .page .entry-header:after, .comment-list .comment .reply .comment-reply-link { background-color: %s; }', $primary_color );

    printf( 'a, .primary-text { color: %s; }', $primary_color );

    printf( '.navbar-default .navbar-nav>li>a:hover, .navbar-default .navbar-nav>li>a:focus, .navbar-default .navbar-nav > .current-menu-item > a, .sub-menu > li > a:hover { color: %s; }', $bs_header_hover_text_color );

    printf( '.navbar-default { background-color: %s; }', $bs_header_background_color );
    
    printf( 'html, body { color: %s; }', $text_color );

    printf( '.btn-primary:hover, .btn-primary:focus, .site-header .bootsnipp-search .search-form .input-group-btn > .search-submit:hover, .comment-form .form-submit input[type="submit"]:hover, .comment-form .form-submit input[type="submit"]:focus, .comment-list .comment .reply .comment-reply-link:hover, .comment-list .comment .reply .comment-reply-link:focus { background-color: %s; }', $hover_color );

    printf( 'a:focus, a:hover { color: %s; }', $hover_color );

    printf( '.navbar-default .navbar-nav>li>a, .site-title a, p.site-description { color: %s; }', $bs_header_text_color );
}

/**
 * Custom logo
 */
function bestshopper_bs_custom_logo($logo) {
?>
    <a href="<?php echo site_url(); ?>" class="custom-logo-link" rel="home" aria-current="page">
        <img width="427" height="146" src="<?php echo $logo; ?>" class="custom-logo" alt="Best Shopper" />
    </a>
<?php
}