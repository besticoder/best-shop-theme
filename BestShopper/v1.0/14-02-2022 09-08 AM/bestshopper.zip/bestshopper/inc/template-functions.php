<?php

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package bestshopper
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function bestshopper_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( !is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( !is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	} else {
		$classes[] = bestshopper_get_sidebar_pos() . '-sidebar';
	}

	$classes[] = 'box-layout';

	return $classes;
}

add_filter( 'body_class', 'bestshopper_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function bestshopper_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}

add_action( 'wp_head', 'bestshopper_pingback_header' );

/**
 * Get classes for primary section.
 * @param type $class
 */
function bestshopper_primary_section_class( $class = array() ) {
	$post_layout  = get_post_meta(get_the_ID(), 'bestshopper_post_layout');

	if($post_layout != 'default') {
		$bs_layout_type = $post_layout[0];
	} else {
		$bs_layout_type = ot_get_option( 'bs_layout_type' );
	}

	$class[] = 'content-area';

	if($bs_layout_type == 'full-width') {
		$class[] = 'col-sm-12';
	} else if($bs_layout_type == 'right-sidebar') {
		$class[] = 'col-sm-8';
	} else if($bs_layout_type == 'left-sidebar') {
		$class[] = 'col-sm-8';
		$class[] = 'col-sm-push-4';
	} else {
		$class[] = 'col-sm-8';
	}

	$class = apply_filters( 'bestshopper_primary_section_class', $class );
	$class_str = esc_html( implode( ' ', $class ) );
	echo 'class="' . $class_str . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Get classes for secondary section.
 * @param type $class
 */
function bestshopper_secondary_section_class( $class = array() ) {
	$is_sidebar   = get_post_meta(get_the_ID(), 'bestshopper_post_is_sidebar');
	$post_layout  = get_post_meta(get_the_ID(), 'bestshopper_post_layout');

	if(isset($is_sidebar) && !empty($is_sidebar)) {
		$bs_layout_status = $is_sidebar[0];
	} else {
		$bs_layout_status = ot_get_option( 'bs_layout_status' );
	}

	$class[] = 'widget-area';

	if($bs_layout_status != 'on') {
		$class[] = 'hidden';
	} else {
		if($post_layout != 'default') {
			$bs_layout_type = $post_layout[0];
		} else {
			$bs_layout_type = ot_get_option( 'bs_layout_type' );
		}

		if($bs_layout_type == 'right-sidebar') {
			$class[] = 'col-sm-4';
		} else if($bs_layout_type == 'left-sidebar') {
			$class[] = 'col-sm-4';
			$class[] = 'col-sm-pull-8';
		} else {
			$class[] = 'col-sm-4';
		}
	}

	$class = apply_filters( 'bestshopper_secondary_section_class', $class );
	$class_str = esc_html( implode( ' ', $class ) );
	echo 'class="' . $class_str . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Get classes for content section.
 * @param type $class
 */
function bestshopper_content_section_class( $class = array() ) {
	$class[] = 'site-content';
	$class[] = 'container';
	$class = apply_filters( 'bestshopper_content_section_class', $class );
	$class_str = esc_html( implode( ' ', $class ) );
	echo 'class="' . $class_str . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Render footer widgets.
 */
function bestshopper_render_footer_widgets() {
	$disable_footer_widgets = ot_get_option( 'disable_footer_widgets' );
	$bs_footer_type 		= ot_get_option( 'bs_footer_type' );

	if(empty($disable_footer_widgets)) {
		if($bs_footer_type == 'footer-1') {
			$active_area_count = 4;
		} else if($bs_footer_type == 'footer-2') {
			$active_area_count = 3;
		} else if($bs_footer_type == 'footer-3') {
			$active_area_count = 2;
		} else if($bs_footer_type == 'footer-4') {
			$active_area_count = 1;
		} else {
			$active_area_count = 4;
		}

		if ( 0 < $active_area_count ) {
			printf( '<div class="row">' );
			for ( $i = 1; $i <= $active_area_count; $i++ ) {
				$col_sm = round( 12 / $active_area_count );
				printf( '<div class="col-sm-%s">', $col_sm ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				dynamic_sidebar( 'footer-' . $i );
				printf( '</div><!-- .col-sm-%s -->', $col_sm ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			printf( '</div><!-- .row -->' );
		}
	}
}

/**
 * Use to get sidebar position.
 * @return string
 */
function bestshopper_get_sidebar_pos(){
	return esc_attr( get_theme_mod( 'bestshopper_sidebar_pos', 'right' ) );
}

function bestshopper_social_media() {
	$bs_social_media_links 	= ot_get_option( 'bs_social_media_links' );

	if(!empty($bs_social_media_links)) {
		$html .= '<ul class="bs-social-media">';
		foreach ($bs_social_media_links as $key => $value) {
			$html .= '<li><a href="'. $value["bs_social_media_link"] .'" target="_blank">';
			$html .= '<i class="fa fa-'. $value["bs_social_media_icon"] .' fa-lg"></i>';
			$html .= '</a></li>';
		}
		$html .= '</ul>';	

		printf($html);
	}
}