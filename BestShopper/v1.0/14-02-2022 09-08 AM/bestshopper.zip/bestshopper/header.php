<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bestshopper
 */

$bs_header_type 	= ot_get_option( 'bs_header_type' );
$bs_logo_upload 	= ot_get_option( 'bs_logo_upload' );
$bs_site_title  	= ot_get_option( 'bs_site_title' );
$bs_site_sub_title  = ot_get_option( 'bs_site_sub_title' );
$bs_options 		= array(
	'bs_custom_logo' 	=> $bs_logo_upload, 
	'bs_site_title' 	=> $bs_site_title, 
	'bs_site_sub_title' => $bs_site_sub_title
);

?>
<!doctype html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="https://gmpg.org/xfn/11">

		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>

		<?php
		if ( function_exists( 'wp_body_open' ) ) {
			wp_body_open();
		}
		?>

		<div id="page" class="site">

			<a class="skip-link screen-reader-text" href="#content">
				<?php esc_html_e( 'Skip to content', 'bestshopper' ); ?>
			</a>

			<?php
				// Header Type
				if(isset($bs_header_type) && $bs_header_type == 'header-1') {
					get_template_part( 'template-parts/header/header-1', 'header-1', $bs_options );
				} else if(isset($bs_header_type) && $bs_header_type == 'header-2') {
					get_template_part( 'template-parts/header/header-2', 'header-2', $bs_options );
				} else {
					get_template_part( 'template-parts/header/header-1', 'header-1', $bs_options );
				}
			?>

			<div id="content" <?php bestshopper_content_section_class(); ?>>
				<div class="row">
