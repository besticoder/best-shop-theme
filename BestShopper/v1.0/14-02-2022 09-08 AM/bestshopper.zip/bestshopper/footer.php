<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bestshopper
 */

$disable_footer_widgets = ot_get_option( 'disable_footer_widgets' );

?>

				</div><!-- .row -->
			</div><!-- #content -->

			<footer id="colophon" class="site-footer <?php echo !empty($disable_footer_widgets) ? 'disable-footer-widgets' : ''; ?>">
				<div class="container">

					<?php bestshopper_render_footer_widgets(); ?>

					<div class="site-info <?php echo !empty($disable_footer_widgets) ? 'disable-footer-widgets' : ''; ?>">
						<div class="pull-right">
							<?php printf('© 2022 All Rights Reserved. Design & Developed By <a href="https://www.besticoder.com/" target="_blank">Besticoder</a>') ?>
						</div><!-- .pull-right -->

						<?php bestshopper_social_media(); ?>

					</div><!-- .site-info -->
				</div><!-- .container -->
			</footer><!-- #colophon -->
		</div><!-- #page -->

	<?php wp_footer(); ?>

	</body>
</html>
