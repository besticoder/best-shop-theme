<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bestshopper
 */

$post_sidebar = get_post_meta(get_the_ID(), 'bestshopper_post_sidebar');

if($post_sidebar != 'default') {
    $bs_select_sidebar  = $post_sidebar[0];
} else {
    $bs_select_sidebar  = ot_get_option('bs_select_sidebar');
}

?>

<aside id="secondary" <?php bestshopper_secondary_section_class(); ?>>
	<?php dynamic_sidebar( $bs_select_sidebar ); ?>
</aside><!-- #secondary -->
