== bestshopper ==

Tags: woo, woocommerece, blog, custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 4.0
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 1.0.5
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0-standalone.html

== Description ==

Best WooCommerce. As for the features, the theme provides a responsive design, widgets, user comments, social links, multiple colors, custom backgrounds, and it’s translation ready.

== COPYRIGHT AND LICENSE ==

bestshopper WordPress Theme, Copyright 2022 besticoder.com
bestshopper is distributed under the terms of the GNU GPL

External resources linked to the theme.

 - Bootstrap v3.3.7 (http://getbootstrap.com)
    Copyright 2011-2016 Twitter, Inc.
    Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

 - Font Awesome 4.7.0 by @davegandy - http://fontawesome.io
    License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

 - Nunito (Google font) https://fonts.google.com/specimen/Nunito
    Open Font License, http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web

Other custom js files are our own creation and is licensed under the same license as this theme.

All other resources and theme elements are licensed under the [GNU GPL](https://www.gnu.org/licenses/gpl-3.0-standalone.html), version 3 or later.

== THEME USAGE ==

= Theme Instruction =
Get theme instruction at https://besticoder.com/themes/bestshopper/

== Changelog ==

= Version 1.0.0 =
* All brand new.