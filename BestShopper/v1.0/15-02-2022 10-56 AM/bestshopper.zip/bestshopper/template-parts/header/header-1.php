<header id="masthead" class="site-header">
	<nav id="site-navigation" class="navbar navbar-default" role="navigation">
		<div class="container">
			<div class="navbar-header">

				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary-menu">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button><!-- .navbar-toggle -->

				<?php
					$bestshopper_description = $args['bs_site_sub_title']; if(!$bestshopper_description) { $class = ' title-align-center'; }
				?>

				<div class="navbar-brand<?php echo $class; ?>">
				<?php 
					if(isset($args['bs_custom_logo']) && !empty($args['bs_custom_logo'])) {
						bestshopper_bs_custom_logo($args['bs_custom_logo']);
					} else { ?>

					<h1 class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php echo esc_html(!empty($args['bs_site_title']) ? $args['bs_site_title'] : get_bloginfo( 'name', 'display' )); ?>
						</a>
					</h1>

				<?php if ( $bestshopper_description || is_customize_preview() ) { ?>
							<p class="site-description">
								<?php echo esc_html(!empty($bestshopper_description) ? $bestshopper_description : get_bloginfo( 'description' ) ); ?>
							</p>
							<?php
						}
					}
				?>

				</div><!-- .navbar-brand -->
			</div><!-- .navbar-header -->

			<div id="primary-menu" class="collapse navbar-collapse">
				<div class="navbar-right">

					<?php
					wp_nav_menu( array(
						'theme_location' => 'primary',
						'container'		 => 'ul',
						'menu_id'		 => 'primary-menu-2',
						'menu_class'	 => 'nav navbar-nav',
					) );
					?>

					<ul class="nav navbar-nav navbar-right search-bar">
                        <li class="">
                        	<a href="#toggle-search" class="animate"><i class="fa fa-search"></i> <i class="fa fa-times"></i></a>
                        </li>                
					</ul>

				</div><!-- .navbar-right -->
			</div><!-- #primary-menu -->
		</div><!-- .container -->
		<div class="bootsnipp-search animate">
            <div class="container">
				<?php get_search_form(); ?>
            </div>
        </div>
	</nav><!-- #site-navigation -->
</header><!-- #masthead -->