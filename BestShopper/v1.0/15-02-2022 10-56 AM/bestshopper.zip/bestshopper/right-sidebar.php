<?php
/**
 * Template Name: BestShopper Right Sidebar
 * Template Post Type: post, page, product
 *
 * @package bestshopper
 */

$is_sidebar   = get_post_meta($post->ID, 'bestshopper_post_is_sidebar');
$post_sidebar = get_post_meta(get_the_ID(), 'bestshopper_post_sidebar');

get_header();
?>

	<div id="primary" class="col-sm-8">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

	<aside id="secondary" class="col-sm-4 <?php echo ($is_sidebar[0] == 'off') ? 'hidden' : ''; ?>">
		<?php dynamic_sidebar( $post_sidebar[0] ); ?>
	</aside><!-- #secondary -->
	
<?php
get_footer();