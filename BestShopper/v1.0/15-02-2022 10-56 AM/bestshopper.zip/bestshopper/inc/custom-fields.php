<?php

add_action( 'add_meta_boxes', 'bestshopper_post_sidebar_meta_box' );
add_action( 'save_post', 'bestshopper_post_sidebar_save', 10,3 );

/**
 * Adds the meta box to the page screen
 */
function bestshopper_post_sidebar_meta_box() {
    add_meta_box(
        'bestshopper_post_sidebar', 	// id, used as the html id att
        __( 'BestShopper Attributes', 'bestshopper' ), // meta box title, like "Page Attributes"
        'bestshopper_post_sidebar_cb', 	// callback function, spits out the content
        array('post', 'page'), 			// post type or page. We'll add this to pages only
        'side', 						// context (where on the screen)
        'low' 							// priority, where should this go in the context?
    );
}

function bestshopper_post_sidebar_save($post_id, $post, $update) {
	update_post_meta( $post_id, 'bestshopper_post_sidebar', $_POST['bestshopper_post_sidebar'] );
	update_post_meta( $post_id, 'bestshopper_post_is_sidebar', isset($_POST['bestshopper_post_is_sidebar']) ? 'off' : 'on' );
}

/**
 * Callback function for our meta box.  Echos out the content
 */
function bestshopper_post_sidebar_cb( $post ) {
	global $wp_registered_sidebars;
	$post_sidebar = get_post_meta($post->ID, 'bestshopper_post_sidebar');
	$is_sidebar   = get_post_meta($post->ID, 'bestshopper_post_is_sidebar');
?>
	<p class="post-attributes-label-wrapper">
		<label class="post-attributes-label" for="bestshopper_post_sidebar"><?php echo _e( 'Select Sidebar', 'bestshopper' ); ?></label>
	</p>
	<select name="bestshopper_post_sidebar">
		<?php foreach ($wp_registered_sidebars as $key => $value) { ?>
		<option value="<?php echo $key; ?>" <?php echo ($post_sidebar[0] == $key) ? 'selected' : ''; ?>><?php echo $value['name']; ?></option>
		<?php } ?>
	</select>
	<p><i><?php echo _e( 'Note: Selected Sidebar only show when selected template is Right or Left Sidebar', 'bestshopper' ); ?></i></p><hr>

	<p class="post-attributes-label-wrapper">
		<input type="checkbox" name="bestshopper_post_is_sidebar" value="on" <?php echo ($is_sidebar[0] == 'off') ? 'checked' : ''; ?>>
		<label class="post-attributes-label" for="bestshopper_post_is_sidebar"><?php echo _e( 'Disable Sidebar', 'bestshopper' ); ?></label>
	</p>
	<p><i><?php echo _e( 'Note: Check if you want to disable the sidebar', 'bestshopper' ); ?></i></p><hr>
<?php
}