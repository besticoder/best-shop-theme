<?php

add_action( 'after_switch_theme', 'bestshopper_add_new_entry' );
add_action( 'admin_init', 'bestshopper_confirm_new_email' );

/**
 * Get information about who installed the theme
 */
function bestshopper_add_new_entry () {
    if(get_option('bestshopper_first_activation') === false){
    	$activation_key 	= bestshopper_get_key();

      	// Set a flag if the theme activation happened
      	add_option('bestshopper_first_activation', true, '', false);
      	add_option('bestshopper_first_activation_key', $activation_key, '', false);
      	// stuff here only runs once, when the theme is activated for the 1st time

      	$first_name 		= get_user_meta( 1, 'first_name', true );
      	$last_name 			= get_user_meta( 1, 'last_name', true );
      	$author_domain		= $_SERVER['SERVER_NAME'];
      	$author_ipaddress 	= bestshopper_get_ipaddress();
      	$author_email 		= get_option( 'admin_email' );
      	$activation_key 	= $activation_key;

		wp_safe_remote_post( 'http://bestshopper.besticoder.com/wp-json/wp/v1/bb-add-new-entry', array(
		    'method'      => 'POST',
		    'blocking'    => true,
		    'body'        => array(
		    	'first_name'   		=> $first_name, 
		    	'last_name'    		=> $last_name, 
		    	'author_email' 		=> $author_email,
		    	'author_domain'		=> $author_domain,
		    	'author_ipaddress' 	=> $author_ipaddress,
		    	'activation_key' 	=> $activation_key
		    	),
		    )
		);
    }
}

/**
 * Gets IP address.
 */
function bestshopper_get_ipaddress() {
	$ipAddress = '';
	if (! empty($_SERVER['HTTP_CLIENT_IP'])) {
		// to get shared ISP IP address
		$ipAddress = $_SERVER['HTTP_CLIENT_IP'];
	} else if (! empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		// check for IPs passing through proxy servers
		// check if multiple IP addresses are set and take the first one
		$ipAddressList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
		foreach ($ipAddressList as $ip) {
			if (! empty($ip)) {
				// if you prefer, you can check for valid IP address here
				$ipAddress = $ip;
				break;
			}
		}
	} else if (! empty($_SERVER['HTTP_X_FORWARDED'])) {
		$ipAddress = $_SERVER['HTTP_X_FORWARDED'];
	} else if (! empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
		$ipAddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
	} else if (! empty($_SERVER['HTTP_FORWARDED_FOR'])) {
		$ipAddress = $_SERVER['HTTP_FORWARDED_FOR'];
	} else if (! empty($_SERVER['HTTP_FORWARDED'])) {
		$ipAddress = $_SERVER['HTTP_FORWARDED'];
	} else if (! empty($_SERVER['REMOTE_ADDR'])) {
		$ipAddress = $_SERVER['REMOTE_ADDR'];
	}

	return $ipAddress;
}

function bestshopper_get_key() {
	return bestshopper_random_num(4).'-'.bestshopper_random_num(4).'-'.bestshopper_random_num(4).'-'.bestshopper_random_num(4);
}

function bestshopper_random_num($size) {
	$alpha_key 	= '';
	$keys 		= range('A', 'Z');
	
	for ($i = 0; $i < 2; $i++) {
		$alpha_key .= $keys[array_rand($keys)];
	}
	
	$length = $size - 2;
	$key 	= '';
	$keys 	= range(0, 9);
	
	for ($i = 0; $i < $length; $i++) {
		$key .= $keys[array_rand($keys)];
	}
	
	return $alpha_key . $key;
}

function bestshopper_confirm_new_email() {
	global $pagenow;
	if(get_current_user_id() == 1) {
	 	$adminhash = get_option( 'adminhash' );
	 	if(empty($adminhash) && $_GET['updated'] == 'true' && $pagenow == 'options-general.php') {
	 		$new_email 		= get_option( 'admin_email' );
	 		$activation_key	= get_option( 'bestshopper_first_activation_key' );

	 		$result = wp_safe_remote_post( 'http://bestshopper.besticoder.com/wp-json/wp/v1/bb-update-author-email', array(
			    'method'      => 'POST',
			    'blocking'    => true,
			    'body'        => array(
			    	'new_email' 		=> $new_email,
			    	'activation_key' 	=> $activation_key
			    	),
			    )
			);
	 	}
	}
}
