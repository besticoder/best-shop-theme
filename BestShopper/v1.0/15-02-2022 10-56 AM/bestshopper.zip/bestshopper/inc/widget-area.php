<?php

/**
 * Widget area file for widgets and registers
 *
 * @package bestshopper
 */

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function bestshopper_widgets_init() {
	register_sidebar( array(
		'name'			 => esc_html__( 'Sidebar', 'bestshopper' ),
		'id'			 => 'sidebar-1',
		'description'	 => esc_html__( 'Add widgets here.', 'bestshopper' ),
		'before_widget'	 => '<div id="%1$s" class="widget %2$s">',
		'after_widget'	 => '</div>',
		'before_title'	 => '<h3 class="widget-title">',
		'after_title'	 => '</h3>',
	) );

	register_sidebar( array(
		'name'			 => esc_html__( 'Footer 1', 'bestshopper' ),
		'id'			 => 'footer-1',
		'description'	 => esc_html__( 'Add widgets here.', 'bestshopper' ),
		'before_widget'	 => '<div id="%1$s" class="widget %2$s">',
		'after_widget'	 => '</div>',
		'before_title'	 => '<h3 class="widget-title">',
		'after_title'	 => '</h3>',
	) );
	register_sidebar( array(
		'name'			 => esc_html__( 'Footer 2', 'bestshopper' ),
		'id'			 => 'footer-2',
		'description'	 => esc_html__( 'Add widgets here.', 'bestshopper' ),
		'before_widget'	 => '<div id="%1$s" class="widget %2$s">',
		'after_widget'	 => '</div>',
		'before_title'	 => '<h3 class="widget-title">',
		'after_title'	 => '</h3>',
	) );
	register_sidebar( array(
		'name'			 => esc_html__( 'Footer 3', 'bestshopper' ),
		'id'			 => 'footer-3',
		'description'	 => esc_html__( 'Add widgets here.', 'bestshopper' ),
		'before_widget'	 => '<div id="%1$s" class="widget %2$s">',
		'after_widget'	 => '</div>',
		'before_title'	 => '<h3 class="widget-title">',
		'after_title'	 => '</h3>',
	) );
	register_sidebar( array(
		'name'			 => esc_html__( 'Footer 4', 'bestshopper' ),
		'id'			 => 'footer-4',
		'description'	 => esc_html__( 'Add widgets here.', 'bestshopper' ),
		'before_widget'	 => '<div id="%1$s" class="widget %2$s">',
		'after_widget'	 => '</div>',
		'before_title'	 => '<h3 class="widget-title">',
		'after_title'	 => '</h3>',
	) );
}

add_action( 'widgets_init', 'bestshopper_widgets_init' );
