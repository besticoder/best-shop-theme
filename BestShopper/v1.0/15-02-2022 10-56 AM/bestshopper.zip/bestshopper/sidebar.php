<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bestshopper
 */

$bs_select_sidebar  = ot_get_option('bs_select_sidebar');

?>

<aside id="secondary" <?php bestshopper_secondary_section_class(); ?>>
	<?php dynamic_sidebar( $bs_select_sidebar ); ?>
</aside><!-- #secondary -->
